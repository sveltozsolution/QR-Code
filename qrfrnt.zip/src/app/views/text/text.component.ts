import { Component } from '@angular/core';

@Component({
  templateUrl: 'text.component.html'
})
export class TextComponent {

  constructor() { }
}
