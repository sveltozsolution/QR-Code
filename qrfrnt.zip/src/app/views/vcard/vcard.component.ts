import { Component } from '@angular/core';

@Component({
  templateUrl: 'vcard.component.html'
})
export class VcardComponent {
 
    
      constructor() { }
    
}
