import { Component } from '@angular/core';

@Component({
  templateUrl: 'payment.component.html'
})
export class PaymentComponent {


}
