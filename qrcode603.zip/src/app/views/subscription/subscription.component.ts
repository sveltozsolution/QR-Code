import { Component } from '@angular/core';

@Component({
  templateUrl: 'subscription.component.html'
})
export class SubscriptionComponent {


}
