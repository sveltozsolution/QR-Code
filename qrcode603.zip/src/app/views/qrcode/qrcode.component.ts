import { Component } from '@angular/core';

@Component({
  templateUrl: 'qrcode.component.html'
})
export class QrcodeComponent {
 
    
      constructor() { }
    
}
