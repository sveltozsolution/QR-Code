import { Component } from '@angular/core';

@Component({
  templateUrl: 'setting.component.html'
})
export class SettingComponent {
 
    
      constructor() { }
    
}
