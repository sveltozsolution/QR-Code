import { Component } from '@angular/core';

@Component({
  templateUrl: 'personal.component.html'
})
export class PersonalComponent {


}
