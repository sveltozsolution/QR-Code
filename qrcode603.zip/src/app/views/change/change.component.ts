import { Component } from '@angular/core';

@Component({
  templateUrl: 'change.component.html'
})
export class ChangeComponent {


}
